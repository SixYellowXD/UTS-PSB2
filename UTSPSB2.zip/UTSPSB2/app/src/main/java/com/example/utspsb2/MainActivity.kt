package com.example.utspsb2

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var cat: ImageView
    private lateinit var dog: ImageView
    private lateinit var turtle: ImageView
    private lateinit var chameleon: ImageView
    private lateinit var hamster: ImageView
    private lateinit var rabbit: ImageView
    private lateinit var snake: ImageView
    private lateinit var tarantula: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        cat = findViewById(R.id.Cat)
        dog = findViewById(R.id.Dog)
        turtle = findViewById(R.id.Turtle)
        chameleon = findViewById(R.id.Chameleon)
        hamster = findViewById(R.id.Hamster)
        rabbit = findViewById(R.id.Rabbit)
        snake = findViewById(R.id.Snake)
        tarantula = findViewById(R.id.Tarantula)

        cat.setOnClickListener(this)
        dog.setOnClickListener(this)
        turtle.setOnClickListener(this)
        chameleon.setOnClickListener(this)
        hamster.setOnClickListener(this)
        rabbit.setOnClickListener(this)
        snake.setOnClickListener(this)
        tarantula.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        when (v.id) {
            R.id.Cat -> {
                Toast.makeText(this, "Cat", Toast.LENGTH_SHORT).show()
                val catIntent = Intent(this, BioActivity::class.java).apply {
                    putExtra("name", "Jack")
                    putExtra("bio", "Jack adalah kucing hitam berumur 6 bulan. Dia memiliki bercak bulu putih di sana-sini. Di sekitar wajahnya terdapat sepetak bulu berwarna putih seperti bayangan, di tengahnya terlihat mata biru Jack yang besar, cerah, dan bulat. Melalui patch tersebut, Anda juga dapat melihat kumis hitamnya yang menonjol. Dia suka mendapatkan kasih sayang dan perhatian serta bermain dengan semua orang yang menginginkannya.")
                }
                startActivity(catIntent)
            }
            R.id.Dog -> {
                Toast.makeText(this, "Dog", Toast.LENGTH_SHORT).show()
                val dogIntent = Intent(this, BioActivity::class.java).apply {
                    putExtra("name", "Max")
                    putExtra("bio", "Max adalah Korgy berwarna coklat berusia tiga tahun. Dia ramah keluarga tetapi agresif terhadap orang asing. Selain setia, dia sangat penurut dan cerdas. Dia dulunya adalah anjing pelacak. Aktivitas fisik seperti berlari, bermain, melompat, dll membuatnya lebih bahagia, dan dia tidak suka duduk diam.")
                }
                startActivity(dogIntent)
            }
            R.id.Turtle -> {
                Toast.makeText(this, "Turtle", Toast.LENGTH_SHORT).show()
                val turtleIntent = Intent(this, BioActivity::class.java).apply {
                    putExtra("name", "Flippy")
                    putExtra("bio", "Flippy adalah kura-kura kecil Reeve. Ini adalah salah satu kura-kura yang paling ramah di antara semua kura-kura. Cangkangnya berwarna hijau tua dan coklat, matanya seperti manik-manik hitam, dan lubang kecil di telinganya. Di belakang kedua telinganya terdapat bintik-bintik merah cerah seukuran bintik tinta. Flippy suka makan keju dan suka bermain kelereng.")
                }
                startActivity(turtleIntent)
            }
            R.id.Chameleon -> {
                Toast.makeText(this, "Chameleon", Toast.LENGTH_SHORT).show()
                val chameleonIntent = Intent(this, BioActivity::class.java).apply {
                    putExtra("name", "Ziggy")
                    putExtra("bio", "Ziggy adalah makhluk yang luar biasa. Dia adalah bunglon sejati, juga dikenal sebagai ''bunglon dunia lama''. Pedas ini terkenal karena kemampuannya mengubah warna sehingga membuatnya menjadi hewan peliharaan yang menarik. Dia suka memanjat pohon, mencari tempat sempurna untuk bersembunyi dan melamun, atau berburu serangga untuk dimakan. Dia adalah pilihan tepat bagi mereka yang siap menghadapi tantangan.")
                }
                startActivity(chameleonIntent)
            }
            R.id.Hamster -> {
                Toast.makeText(this, "Hamster", Toast.LENGTH_SHORT).show()
                val hamsterIntent = Intent(this, BioActivity::class.java).apply {
                    putExtra("name", "Einstein")
                    putExtra("bio", "Einstein berumur dua bulan. Dia adalah hamster yang menggemaskan dan memiliki bulu yang benar-benar putih di sekujur tubuhnya. Einstein suka berlarian keliling ruangan ketika dia dikeluarkan dari kandangnya. Dia sangat penuh energi dan sangat suka digandeng. Dia suka makan banyak kacang. Kadang-kadang, dia mengeluarkan suara mencicit untuk menunjukkan protesnya karena memegangnya terlalu lama dan \" +\n" +
                            "                            “Ketika dilepas ke lantai dia akan mulai berlari lagi.")
                }
                startActivity(hamsterIntent)
            }
            R.id.Rabbit -> {
                Toast.makeText(this, "Rabbit", Toast.LENGTH_SHORT).show()
                val rabbitIntent = Intent(this, BioActivity::class.java).apply {
                    putExtra("name", "Oreo")
                    putExtra("bio", "Oreo adalah kelinci berumur lima bulan dan memiliki bulu berwarna putih. Dia memiliki mata merah yang lucu dan cakarnya berwarna coklat di tepinya. Dia cerdas dan penuh energi. Dia suka makan wortel dan daun ketumbar. Balapan dengan kelinci lain adalah hal favoritnya.")
                }
                startActivity(rabbitIntent)
            }
            R.id.Snake -> {
                Toast.makeText(this, "Snake", Toast.LENGTH_SHORT).show()
                val snakeIntent = Intent(this, BioActivity::class.java).apply {
                    putExtra("name", "Noodles")
                    putExtra("bio", "Noodles adalah ular jagung, salah satu ular yang paling populer untuk dipelihara sebagai hewan peliharaan. Mie tidak berbisa dan panjangnya hanya 4 inci. Dia hiperaktif dan suka bergerak. Dia suka bergerak sambil digandeng. Dia bisa menggigit jika dia merasa terancam tetapi gigitannya tidak terlalu menyakitkan.")
                }
                startActivity(snakeIntent)
            }
            R.id.Tarantula -> {
                Toast.makeText(this, "Tarantula", Toast.LENGTH_SHORT).show()
                val tarantulaIntent = Intent(this, BioActivity::class.java).apply {
                    putExtra("name", "Lucas")
                    putExtra("bio", "Lucas adalah laba-laba tarantula, sangat menyenangkan untuk diamati. Namun, penanganannya kurang tepat dan dapat menimbulkan rasa gatal atau alergi jika tidak ditangani dengan benar. Ia suka berada di kandang kecilnya dan hanya perlu diberi makan seminggu sekali. Dia memakan cacing, jangkrik, dan kecoak. Memiliki dia lebih seperti koleksi daripada memiliki hewan peliharaan.")
                }
                startActivity(tarantulaIntent)
            }
        }
    }
}


package com.example.utspsb2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class BioActivity : AppCompatActivity() {

    private lateinit var petImage: ImageView
    private lateinit var petName: TextView
    private lateinit var petBio: TextView
    private var extras: Bundle? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bio)

        petImage = findViewById(R.id.PetImage)
        petName = findViewById(R.id.Name)
        petBio = findViewById(R.id.Bio)

        extras = intent.extras

        extras?.let {
            val name = it.getString("name")
            val bio = it.getString("bio")

            setUp(name, bio)
        }
    }

    private fun setUp(name: String?, bio: String?) {
        when (name) {
            "Jack" -> {
                petImage.setImageDrawable(resources.getDrawable(R.drawable.cat_img, null))
                petName.text = name
                petBio.text = bio
            }
            "Max" -> {
                petImage.setImageDrawable(resources.getDrawable(R.drawable.dog_img, null))
                petName.text = name
                petBio.text = bio
            }
            "Flippy" -> {
                petImage.setImageDrawable(resources.getDrawable(R.drawable.turtle_img, null))
                petName.text = name
                petBio.text = bio
            }
            "Ziggy" -> {
                petImage.setImageDrawable(resources.getDrawable(R.drawable.chameleon_img, null))
                petName.text = name
                petBio.text = bio
            }
            "Einstein" -> {
                petImage.setImageDrawable(resources.getDrawable(R.drawable.hamster_img, null))
                petName.text = name
                petBio.text = bio
            }
            "Oreo" -> {
                petImage.setImageDrawable(resources.getDrawable(R.drawable.rabbit_img, null))
                petName.text = name
                petBio.text = bio
            }
            "Noodles" -> {
                petImage.setImageDrawable(resources.getDrawable(R.drawable.snake_img, null))
                petName.text = name
                petBio.text = bio
            }
            "Lucas" -> {
                petImage.setImageDrawable(resources.getDrawable(R.drawable.tarantula_img, null))
                petName.text = name
                petBio.text = bio
            }
        }
    }
}

